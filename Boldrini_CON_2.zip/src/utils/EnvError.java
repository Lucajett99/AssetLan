package utils;

public enum EnvError {
    DECLARED, //no error
    ALREADY_DECLARED, //Multiple Declaration
    NO_DECLARE,//things that search is not found(Varible not declared)
    OTHER      //Other Error
}
